/*
 * Copyright (c) 2026 k2-fsa
 * SPDX-License-Identifier: Apache-2.0
 *
 * Based on sherpa-onnx v1.13.7 kotlin-api/OnlineRecognizer.kt. Kept with the
 * official JNI package and signatures because the native v1.13.7 binary uses
 * this API. See app/src/main/assets/licenses/sherpa-onnx-NOTICE.txt.
 */
package com.k2fsa.sherpa.onnx

import android.content.res.AssetManager

data class EndpointRule(var mustContainNonSilence: Boolean, var minTrailingSilence: Float, var minUtteranceLength: Float)
data class EndpointConfig(
    var rule1: EndpointRule = EndpointRule(false, 2.4f, 0.0f),
    var rule2: EndpointRule = EndpointRule(true, 1.4f, 0.0f),
    var rule3: EndpointRule = EndpointRule(false, 0.0f, 20.0f),
)
data class QnnConfig(var backendLib: String = "", var contextBinary: String = "", var systemLib: String = "")
data class FeatureConfig(var sampleRate: Int = 16_000, var featureDim: Int = 80, var dither: Float = 0.0f)
data class HomophoneReplacerConfig(var dictDir: String = "", var lexicon: String = "", var ruleFsts: String = "")
data class OnlineTransducerModelConfig(var encoder: String = "", var decoder: String = "", var joiner: String = "", var qnnConfig: QnnConfig = QnnConfig())
data class OnlineParaformerModelConfig(var encoder: String = "", var decoder: String = "")
data class OnlineZipformer2CtcModelConfig(var model: String = "")
data class OnlineNeMoCtcModelConfig(var model: String = "")
data class OnlineToneCtcModelConfig(var model: String = "")
data class OnlineModelConfig(
    var transducer: OnlineTransducerModelConfig = OnlineTransducerModelConfig(),
    var paraformer: OnlineParaformerModelConfig = OnlineParaformerModelConfig(),
    var zipformer2Ctc: OnlineZipformer2CtcModelConfig = OnlineZipformer2CtcModelConfig(),
    var neMoCtc: OnlineNeMoCtcModelConfig = OnlineNeMoCtcModelConfig(),
    var toneCtc: OnlineToneCtcModelConfig = OnlineToneCtcModelConfig(),
    var tokens: String = "", var numThreads: Int = 1, var debug: Boolean = false,
    var provider: String = "cpu", var modelType: String = "", var modelingUnit: String = "", var bpeVocab: String = "",
)
data class OnlineLMConfig(var model: String = "", var scale: Float = 0.5f)
data class OnlineCtcFstDecoderConfig(var graph: String = "", var maxActive: Int = 3000)
data class OnlineRecognizerConfig(
    var featConfig: FeatureConfig = FeatureConfig(), var modelConfig: OnlineModelConfig = OnlineModelConfig(),
    var lmConfig: OnlineLMConfig = OnlineLMConfig(), var ctcFstDecoderConfig: OnlineCtcFstDecoderConfig = OnlineCtcFstDecoderConfig(),
    var hr: HomophoneReplacerConfig = HomophoneReplacerConfig(), var endpointConfig: EndpointConfig = EndpointConfig(),
    var enableEndpoint: Boolean = true, var decodingMethod: String = "greedy_search", var maxActivePaths: Int = 4,
    var hotwordsFile: String = "", var hotwordsScore: Float = 1.5f, var ruleFsts: String = "", var ruleFars: String = "", var blankPenalty: Float = 0.0f,
)
data class OnlineRecognizerResult(val text: String, val tokens: Array<String>, val timestamps: FloatArray, val ysProbs: FloatArray)

class OnlineRecognizer(assetManager: AssetManager? = null, val config: OnlineRecognizerConfig) {
    private var ptr: Long = if (assetManager != null) newFromAsset(assetManager, config) else newFromFile(config)
    init { require(ptr != 0L) { "Invalid OnlineRecognizerConfig: failed to create native OnlineRecognizer" } }
    fun release() { if (ptr != 0L) { delete(ptr); ptr = 0L } }
    fun createStream(hotwords: String = "") = OnlineStream(createStream(ptr, hotwords))
    fun reset(stream: OnlineStream) = reset(ptr, stream.ptr)
    fun decode(stream: OnlineStream) = decode(ptr, stream.ptr)
    fun isEndpoint(stream: OnlineStream) = isEndpoint(ptr, stream.ptr)
    fun isReady(stream: OnlineStream) = isReady(ptr, stream.ptr)
    fun getResult(stream: OnlineStream): OnlineRecognizerResult = getResult(ptr, stream.ptr)
    private external fun delete(ptr: Long)
    private external fun newFromAsset(assetManager: AssetManager, config: OnlineRecognizerConfig): Long
    private external fun newFromFile(config: OnlineRecognizerConfig): Long
    private external fun createStream(ptr: Long, hotwords: String): Long
    private external fun reset(ptr: Long, streamPtr: Long)
    private external fun decode(ptr: Long, streamPtr: Long)
    private external fun isEndpoint(ptr: Long, streamPtr: Long): Boolean
    private external fun isReady(ptr: Long, streamPtr: Long): Boolean
    private external fun getResult(ptr: Long, streamPtr: Long): OnlineRecognizerResult
    companion object { init { System.loadLibrary("sherpa-onnx-jni") } }
}
